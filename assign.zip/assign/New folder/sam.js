var fs = require('fs');

var f=fs.readFileSync('main.csv', 'utf8');
var data;
 // console.log(data);


 var row= f.split("\n");
  var row = f.split(",");
// console.log(row);
 for(var i=0;i<row.length;i++){
      var cell = row[i].split(',');
    }
      for (var j = 0; j< cell.length; j++) {
        if (cell[j] == '1')
        console.log(row[j]);
      }
      /*  var header=data[0];
      //  for(var i=0;i<header.length;i++)

        {
          if(header[i]=='CountryName'){
            indexOfCountryName=i;
          }
          if(header[i]=='Area'){
            indexOfArea=i;
        }
        if(header[i]=='Population')
        {
          indexOfPopulation=i;
        }

  }*/

console.log(row);



// console.log(row);
