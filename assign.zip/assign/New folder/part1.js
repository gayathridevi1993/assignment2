var fs = require('fs');

var f=fs.readFileSync('ni.csv', 'utf8');

//console.log(f);
var row= f.split("\n");
//console.log(row);
var i,x,y,z,w,a;
var header=row[0].split(",");
//console.log(header);
for(i=0;i<header.length;i++)
{
 if(header[i]==="Population (Millions) 2013"){
   x=header.indexOf(header[i]);
 }
 if(header[i]==="GDP Billions (USD) 2013"){
    y=header.indexOf(header[i]);
 }
 if(header[i]==="Gross Domestic Product Per Capita Income at Current Price (USD) 2013"){
   z=header.indexOf(header[i]);
 }
 if(header[i]==="Gross domestic product based on Purchasing-Power-Parity (PPP) valuation of Country GDP in Billions (Current International Dollar) 2013"){
    w=header.indexOf(header[i]);
 }
}
//console.log(x);
var final1=[];
var c=[];
var newObj= new Object();
//console.log(row[1]);
for(i=1;i<row.length;i++){
 var contentsep=[];
   contentsep=row[i].split(",");
   c.push(contentsep);
//console.log(c);

//  console.log(contentsep[0]);
 for(a=0;a<c.length;a++){
 var arr=[];
 //for(j=0;j<contentsep.length;j++){
   //console.log(contentsep[0]);
     arr.push({Country:c[0][0],Population:c[0][x],GDPBillions:c[0][y],GrossDomesticProduct:c[0][z], PurchasingPowerParityPPP:c[0][w] });
   //}
}

newObj[final1[i]]=arr;
}
console.log(newObj);
