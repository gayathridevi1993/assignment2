
var fs = require('fs');

var f=fs.readFileSync('Table_1.3.csv', 'utf8');

//console.log(f);
var row= f.split("\n");
//console.log(row);
var i,x,y,z,w,a;
var header=row[0].split(",");
//console.log(header);
for(i=0;i<header.length;i++)
{
 if(header[i]==="Population (Millions) 2013"){
   x=header.indexOf(header[i]);
 }
 if(header[i]==="GDP Billions (USD) 2013"){
    y=header.indexOf(header[i]);
 }
 if(header[i]==="Gross Domestic Product Per Capita Income at Current Price (USD) 2013"){
   z=header.indexOf(header[i]);
 }
 if(header[i]==="Gross domestic product based on Purchasing-Power-Parity (PPP) valuation of Country GDP in Billions (Current International Dollar) 2013"){
    w=header.indexOf(header[i]);
 }
}
//console.log(x);
var final1=[];
var newObj= new Object();
for(i=1;i<row.length;i++){
 //var contentsep=row[i].split(",");
 //console.log(contentsep[0]);
 //for(a=0;a<contentsep.length;a++){
 var arr=[];
 //for(j=0;j<header.length;j++){
   //console.log(contentsep[0]);
     arr.push({Country:contentsep[0],Population:contentsep[x]});
   //}
}

newObj[final1[i]]=arr;
}
//console.log(newObj);
