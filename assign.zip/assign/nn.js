var fs = require('fs');

var f=fs.readFileSync('ni.csv',"utf-8");
//console.log(contents);
var row = f.split("\n");
var i=0,k=0,j=0;
var head=row[0].split(',');
for(i=0;i<head.length;i++)
{
 if(head[i]==="Population (Millions) 2013"){
   x=head.indexOf(head[i]);
 }
 if(head[i]==="GDP Billions (USD) 2013"){
    y=head.indexOf(head[i]);
 }
 if(head[i]==="Gross Domestic Product Per Capita Income at Current Price (USD) 2013"){
   z=head.indexOf(head[i]);
 }
 if(head[i]==="Gross domestic product based on Purchasing-Power-Parity (PPP) valuation of Country GDP in Billions (Current International Dollar) 2013"){
    w=head.indexOf(head[i]);
 }
}

var arr=[];
var final1=[];
var newObj= new Object();
for(i=1;i<row.length;i++)
{
var country=row[i].split(',');

for(j=1;j<country.length;j++)
{
for(k=j;k<head.length;k++)
{
  //arr.push({Country:contentsep[0],Population:contentsep[x]});
  console.log(head[0]+":"+country[0]);
console.log(head[k]+":"+country[j]+"\n");
break;
}
}
}
newObj[final1[i]]=arr;
